# Poly - Multilingual AI Voice Chatbot

## Overview

Poly is a voice-first, multilingual AI chatbot application that enables natural conversations in 11+ languages including English, Hindi, Tamil, Telugu, Kannada, Marathi, Malayalam, Bengali, French, Spanish, and Japanese. The application automatically detects the user's language and responds in the same language, creating a seamless conversational experience.

The platform combines real-time voice input/output with a clean, chat-based interface inspired by modern messaging applications, prioritizing accessibility and ease of use across languages and scripts.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **UI Components**: Shadcn/ui (Radix UI primitives) with New York style variant
- **Styling**: Tailwind CSS with custom design tokens
- **State Management**: TanStack Query (React Query) for server state
- **Build Tool**: Vite

**Design System:**
- Material Design principles with hybrid chat interface patterns
- Primary font: Inter (Google Fonts) for multilingual character support
- Consistent spacing primitives (2, 4, 6, 8 Tailwind units)
- Custom color system supporting light/dark modes via CSS variables
- Voice-first interface with accessibility considerations

**Key UI Components:**
- ChatHeader: Fixed header with language indicator and new chat functionality
- MessageBubble: Chat message display with role-based styling
- ChatInput: Text input with integrated voice button
- VoiceButton: Dedicated voice recording control with visual feedback
- WelcomeScreen: Language selection interface
- TypingIndicator: AI response loading state

**Browser APIs:**
- Web Speech API (SpeechRecognition) for voice input
- Web Speech Synthesis API for text-to-speech output
- Both APIs include feature detection and fallback handling

### Backend Architecture

**Technology Stack:**
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js
- **AI Integration**: OpenAI GPT-5 API
- **Database ORM**: Drizzle ORM (PostgreSQL dialect)
- **Validation**: Zod schemas
- **Module System**: ES Modules

**API Design:**
- RESTful endpoint at `/api/chat` for message processing
- Stateless request handling with conversation history passed from client
- Structured error handling with Zod validation
- Request/response logging middleware

**OpenAI Integration:**
- System prompt defines Poly's personality and multilingual capabilities
- Conversation history maintained client-side and sent with each request
- Language auto-detection through AI model
- Response generation with cultural awareness and natural tone

**Data Flow:**
1. User sends message with optional conversation history
2. Server validates request using Zod schema
3. OpenAI processes message with system prompt and history
4. Response includes detected language and AI-generated message
5. Client updates UI and handles voice synthesis if needed

### External Dependencies

**AI Services:**
- **OpenAI API**: Primary language processing using GPT-5 model
  - Purpose: Multilingual conversation, language detection, natural language understanding
  - Configuration: API key via environment variable (`OPENAI_API_KEY`)
  - Model: gpt-5 (as of August 7, 2025)

**Database:**
- **PostgreSQL**: Relational database via Neon serverless driver
  - Purpose: User data storage (schema defined but minimal usage in current implementation)
  - Configuration: Connection string via `DATABASE_URL` environment variable
  - ORM: Drizzle with migrations support

**UI Component Library:**
- **Radix UI**: Headless component primitives
  - Multiple components: Dialog, Dropdown, Popover, Toast, Accordion, etc.
  - Provides accessibility features out of the box
  - Customized with Tailwind CSS

**Frontend Libraries:**
- **TanStack Query**: Server state management and caching
- **React Hook Form**: Form handling with Zod resolver integration
- **date-fns**: Date formatting and manipulation
- **nanoid**: Unique ID generation for messages
- **class-variance-authority**: Component variant management
- **embla-carousel**: Carousel component functionality

**Development Tools:**
- **Vite**: Fast development server and build tool
- **Replit Plugins**: Runtime error overlay, cartographer, dev banner
- **TypeScript**: Type safety across the stack
- **Drizzle Kit**: Database migration tooling

**Voice Technologies:**
- **Browser Native APIs**: No external service dependencies
  - SpeechRecognition (WebKit/Standard)
  - SpeechSynthesis
  - Language-specific voice selection for TTS

**Session Management:**
- In-memory storage implementation (MemStorage class)
- Designed to support database persistence with minimal changes
- User management schema defined but currently unused

**Build & Deployment:**
- Single-page application architecture
- Express serves static assets in production
- Development mode uses Vite middleware
- Environment-specific configurations for database and API keys