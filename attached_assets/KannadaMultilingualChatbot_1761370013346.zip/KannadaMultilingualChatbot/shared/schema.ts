import { z } from "zod";

// Message schema for chat messages
export const messageSchema = z.object({
  id: z.string(),
  role: z.enum(["user", "assistant"]),
  content: z.string(),
  language: z.string().optional(),
  timestamp: z.number(),
});

export type Message = z.infer<typeof messageSchema>;

// Chat request schema
export const chatRequestSchema = z.object({
  message: z.string().min(1, "Message cannot be empty"),
  conversationHistory: z.array(messageSchema).optional(),
});

export type ChatRequest = z.infer<typeof chatRequestSchema>;

// Chat response schema
export const chatResponseSchema = z.object({
  message: z.string(),
  detectedLanguage: z.string().optional(),
});

export type ChatResponse = z.infer<typeof chatResponseSchema>;

// Supported languages configuration
export const supportedLanguages = [
  { code: "en", name: "English", flag: "🇬🇧", nativeName: "English" },
  { code: "hi", name: "Hindi", flag: "🇮🇳", nativeName: "हिन्दी" },
  { code: "ta", name: "Tamil", flag: "🇮🇳", nativeName: "தமிழ்" },
  { code: "te", name: "Telugu", flag: "🇮🇳", nativeName: "తెలుగు" },
  { code: "kn", name: "Kannada", flag: "🇮🇳", nativeName: "ಕನ್ನಡ" },
  { code: "mr", name: "Marathi", flag: "🇮🇳", nativeName: "मराठी" },
  { code: "ml", name: "Malayalam", flag: "🇮🇳", nativeName: "മലയാളം" },
  { code: "bn", name: "Bengali", flag: "🇮🇳", nativeName: "বাংলা" },
  { code: "fr", name: "French", flag: "🇫🇷", nativeName: "Français" },
  { code: "es", name: "Spanish", flag: "🇪🇸", nativeName: "Español" },
  { code: "ja", name: "Japanese", flag: "🇯🇵", nativeName: "日本語" },
] as const;

export type SupportedLanguage = typeof supportedLanguages[number];
