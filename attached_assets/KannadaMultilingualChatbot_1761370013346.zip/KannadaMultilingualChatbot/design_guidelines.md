# Multilingual AI Voice Chatbot - Design Guidelines

## Design Approach

**Hybrid Approach:** Material Design System + Modern Chat Interface Patterns

Drawing inspiration from ChatGPT's clean conversation flow, Google Assistant's voice-first design, and WhatsApp's familiar messaging patterns, while following Material Design principles for accessibility and voice interaction.

**Core Principle:** Create an inviting, voice-first interface that makes multilingual conversation feel natural and effortless.

---

## Typography

**Primary Font:** Inter (Google Fonts)
- Excellent multilingual character support (including Kannada, Hindi, Tamil scripts)
- Clean, readable at all sizes
- Professional yet friendly

**Hierarchy:**
- App Title/Branding: 24px, semibold (600)
- Message Text: 16px, regular (400)
- Timestamps/Labels: 13px, medium (500)
- Language Indicators: 12px, medium (500)
- Button Text: 15px, medium (500)

---

## Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, and 8
- Message padding: p-4
- Container spacing: p-6
- Component gaps: gap-4
- Section margins: mb-8
- Icon margins: mr-2

**Grid Structure:**
- Single column chat-focused layout (max-w-3xl centered)
- Full viewport height usage for chat interface
- Fixed header and input area, scrollable message area

---

## Component Library

### Core Chat Components

**1. Header Section**
- Logo/brand "Poly" with microphone icon
- Language status indicator (current detected language)
- Settings icon (top right)
- Subtle bottom border for separation
- Height: h-16, fixed position

**2. Message Bubbles**
- User messages: Right-aligned, rounded-2xl corners
- Bot messages: Left-aligned, rounded-2xl corners
- Include avatar (small circle - user initial or "P" for Poly)
- Timestamp below each message (text-xs)
- Language badge (small pill shape) showing detected language
- Max width: max-w-md for readability
- Shadow: subtle drop shadow for depth

**3. Voice Input Section**
- Large circular microphone button (w-16 h-16)
- Pulsing animation when recording/listening
- Visual feedback: wave animation or ripple effect during speech
- Status text: "Tap to speak" / "Listening..." / "Processing..."
- Text input fallback below mic button

**4. Input Area (Fixed Bottom)**
- Text input field with rounded-full style
- Microphone toggle button (right side of input)
- Send button (paper plane icon)
- Height: h-20, with p-4 padding
- Subtle top border for separation

**5. Language Indicator Pills**
- Small rounded-full badges
- Flag emoji + language code (e.g., 🇮🇳 KN, 🇮🇳 HI, 🇫🇷 FR)
- Appears next to each message
- Size: px-3 py-1, text-xs

**6. Welcome Screen (Empty State)**
- Centered content when no messages
- Large microphone icon illustration
- "Hi! I'm Poly 🗣️" heading
- Subtitle: "Speak to me in any language"
- Grid of language cards showing supported languages (3 columns on desktop, 2 on tablet, 1 on mobile)
- Each language card: Flag + Language name, clickable to start conversation

**7. Typing Indicator**
- Three bouncing dots animation
- Appears in bot message bubble style
- Shows "Poly is thinking..." or language-specific equivalent

### Navigation
- Minimal header navigation
- Hamburger menu (mobile) with: New Chat, Language Settings, About Poly, Help
- Desktop: Icon buttons in header for settings and new chat

### Forms & Controls
- Text input: rounded-full, border with focus ring
- Buttons: rounded-full for voice input, rounded-lg for secondary actions
- Toggle switches for settings (enable/disable voice, auto-detect language)

### Data Display
- Chat history: scrollable container with smooth scroll behavior
- Conversation timestamps: grouped by date (Today, Yesterday, Date)
- Message delivery status: subtle checkmarks

---

## Animations

**Strategic Use Only:**

1. **Microphone Button:**
   - Pulse animation when recording (scale effect)
   - Ripple effect on tap
   - Smooth color transition when active

2. **Message Entry:**
   - Gentle fade-in + slide-up for new messages
   - Duration: 300ms ease-out

3. **Typing Indicator:**
   - Bouncing dots (staggered animation)

4. **Language Detection:**
   - Quick fade-in for language badge (200ms)

**No animations for:** Scrolling, hover states, or decorative elements

---

## Layout Sections

### Main Chat Interface (Full Application)

**Header (Fixed Top):**
- Brand + current conversation language
- New chat and settings icons
- h-16 with subtle shadow

**Message Area (Scrollable):**
- Centered container (max-w-3xl)
- Messages with alternating alignment
- Generous vertical spacing (gap-6)
- Auto-scroll to newest message

**Input Area (Fixed Bottom):**
- Voice-first: Large mic button as primary action
- Text input as secondary option
- Quick language switcher (dropdown or pills)
- h-24 with top border

### Empty State / Welcome:
- Centered vertically and horizontally
- Welcome message in multiple scripts
- Language selection cards grid
- Call-to-action: "Start speaking or typing"

---

## Images

**Brand Logo/Icon:**
- Microphone icon with speech bubble (abstract, friendly)
- Use as app logo in header
- Size: 32x32px in header, 64x64px in welcome screen

**User Avatars:**
- Circular placeholders with initials
- Size: 32x32px in chat
- Use colored backgrounds (consistent per user session)

**Welcome Illustration:**
- Abstract illustration of multilingual communication (speech bubbles in different scripts)
- Placement: Center of empty state
- Dimensions: 240x180px
- Style: Modern, minimal line art with a few accent shapes

**No Hero Image:** This is a chat application - focus on functionality, not marketing imagery

---

## Visual Hierarchy Principles

1. **Voice-First Design:** Microphone button is the largest, most prominent element
2. **Conversation Flow:** Clear visual separation between user and bot messages
3. **Language Clarity:** Language indicators are visible but not distracting
4. **Accessibility:** High contrast for message text, clear focus states
5. **Cultural Warmth:** Use flag emojis and friendly language in UI text

---

## Responsive Behavior

**Desktop (1024px+):**
- Chat container: max-w-3xl centered
- Side padding: px-8
- Multi-column language cards in welcome screen

**Tablet (768px-1023px):**
- Chat container: max-w-2xl
- Side padding: px-6
- Two-column language cards

**Mobile (<768px):**
- Full-width chat (px-4)
- Single-column layout throughout
- Larger touch targets for mic button (w-20 h-20)
- Simplified header with hamburger menu

---

## Accessibility Foundations

- All interactive elements have clear focus rings
- Color contrast ratio 4.5:1 minimum for text
- Voice feedback for screen readers during recording
- Keyboard shortcuts: Enter to send, Escape to cancel recording
- Language labels use both text and flag emojis for clarity
- RTL support for applicable languages

---

This design creates a welcoming, functional multilingual voice chatbot that prioritizes ease of use while celebrating linguistic diversity through clear visual indicators and culturally-aware design elements.