import { useState, useCallback, useEffect, useRef } from "react";

interface UseSpeechSynthesisReturn {
  speak: (text: string, language?: string) => void;
  isSpeaking: boolean;
  cancel: () => void;
  isSupported: boolean;
}

export function useSpeechSynthesis(): UseSpeechSynthesisReturn {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const synthRef = useRef<SpeechSynthesis | null>(null);

  const isSupported = typeof window !== "undefined" && "speechSynthesis" in window;

  useEffect(() => {
    if (isSupported) {
      synthRef.current = window.speechSynthesis;
    }
  }, [isSupported]);

  const speak = useCallback((text: string, language?: string) => {
    if (!isSupported || !synthRef.current) {
      console.warn("Speech synthesis is not supported");
      return;
    }

    synthRef.current.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    
    if (language) {
      const languageMap: Record<string, string> = {
        en: "en-US",
        hi: "hi-IN",
        ta: "ta-IN",
        te: "te-IN",
        kn: "kn-IN",
        mr: "mr-IN",
        ml: "ml-IN",
        bn: "bn-IN",
        fr: "fr-FR",
        es: "es-ES",
        ja: "ja-JP",
      };
      utterance.lang = languageMap[language] || "en-US";
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    synthRef.current.speak(utterance);
  }, [isSupported]);

  const cancel = useCallback(() => {
    if (synthRef.current) {
      synthRef.current.cancel();
      setIsSpeaking(false);
    }
  }, []);

  return {
    speak,
    isSpeaking,
    cancel,
    isSupported,
  };
}
