import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Message, ChatRequest, ChatResponse } from "@shared/schema";
import { ChatHeader } from "@/components/ChatHeader";
import { WelcomeScreen } from "@/components/WelcomeScreen";
import { MessageBubble } from "@/components/MessageBubble";
import { TypingIndicator } from "@/components/TypingIndicator";
import { ChatInput } from "@/components/ChatInput";
import { VoiceButton } from "@/components/VoiceButton";
import { useSpeechRecognition } from "@/hooks/useSpeechRecognition";
import { useSpeechSynthesis } from "@/hooks/useSpeechSynthesis";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { nanoid } from "nanoid";

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentLanguage, setCurrentLanguage] = useState<string | undefined>();
  const [pendingVoiceTranscript, setPendingVoiceTranscript] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const {
    isListening,
    transcript,
    interimTranscript,
    startListening,
    stopListening,
    resetTranscript,
    isSupported: isSpeechSupported,
    error: speechError,
  } = useSpeechRecognition();

  const { speak, cancel: cancelSpeech } = useSpeechSynthesis();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (speechError) {
      toast({
        title: "Voice Error",
        description: speechError,
        variant: "destructive",
      });
    }
  }, [speechError, toast]);

  useEffect(() => {
    if (transcript) {
      setPendingVoiceTranscript(transcript);
    }
  }, [transcript]);

  const chatMutation = useMutation({
    mutationFn: async (request: ChatRequest): Promise<ChatResponse> => {
      return apiRequest("POST", "/api/chat", request);
    },
    onSuccess: (data, variables) => {
      const assistantMessage: Message = {
        id: nanoid(),
        role: "assistant",
        content: data.message,
        language: data.detectedLanguage,
        timestamp: Date.now(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
      
      if (data.detectedLanguage) {
        setCurrentLanguage(data.detectedLanguage);
      }

      speak(data.message, data.detectedLanguage);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = (content: string) => {
    if (!content.trim()) return;

    const userMessage: Message = {
      id: nanoid(),
      role: "user",
      content: content.trim(),
      timestamp: Date.now(),
    };

    setMessages((prev) => {
      const updatedMessages = [...prev, userMessage];
      
      chatMutation.mutate({
        message: content.trim(),
        conversationHistory: updatedMessages,
      });
      
      return updatedMessages;
    });
  };

  const handleVoiceToggle = () => {
    if (isListening) {
      stopListening();
      if (pendingVoiceTranscript) {
        handleSendMessage(pendingVoiceTranscript);
        setPendingVoiceTranscript("");
        resetTranscript();
      }
    } else {
      if (!isSpeechSupported) {
        toast({
          title: "Not Supported",
          description: "Voice input is not supported in this browser. Please use Chrome, Edge, or Safari.",
          variant: "destructive",
        });
        return;
      }
      cancelSpeech();
      setPendingVoiceTranscript("");
      startListening();
    }
  };

  const handleNewChat = () => {
    setMessages([]);
    setCurrentLanguage(undefined);
    cancelSpeech();
    resetTranscript();
  };

  const showWelcome = messages.length === 0;
  const isProcessing = chatMutation.isPending;

  return (
    <div className="flex flex-col h-screen bg-background">
      <ChatHeader currentLanguage={currentLanguage} onNewChat={handleNewChat} />

      <main className="flex-1 overflow-hidden pt-16">
        {showWelcome ? (
          <WelcomeScreen />
        ) : (
          <div className="h-full overflow-y-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto py-6 space-y-6">
              {messages.map((message) => (
                <MessageBubble key={message.id} message={message} />
              ))}

              {isProcessing && <TypingIndicator />}

              <div ref={messagesEndRef} />
            </div>
          </div>
        )}
      </main>

      <div className="border-t border-border bg-background">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-4 space-y-4">
          {showWelcome && (
            <div className="flex justify-center">
              <VoiceButton
                isListening={isListening}
                isProcessing={isProcessing}
                onToggle={handleVoiceToggle}
                transcript={pendingVoiceTranscript || interimTranscript}
              />
            </div>
          )}
          <ChatInput
            onSendMessage={handleSendMessage}
            onVoiceClick={handleVoiceToggle}
            disabled={isProcessing}
            isListening={isListening}
          />
        </div>
      </div>
    </div>
  );
}
