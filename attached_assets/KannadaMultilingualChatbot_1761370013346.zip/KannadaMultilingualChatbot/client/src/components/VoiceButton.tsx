import { Mic, MicOff, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface VoiceButtonProps {
  isListening: boolean;
  isProcessing: boolean;
  onToggle: () => void;
  disabled?: boolean;
  transcript?: string;
}

export function VoiceButton({ isListening, isProcessing, onToggle, disabled, transcript }: VoiceButtonProps) {
  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative">
        {isListening && (
          <>
            <div className="absolute inset-0 rounded-full bg-destructive/20 animate-ping" />
            <div className="absolute inset-0 rounded-full bg-destructive/10 animate-pulse" style={{ animationDuration: "1.5s" }} />
          </>
        )}
        <Button
          size="icon"
          variant={isListening ? "default" : "outline"}
          className={cn(
            "w-16 h-16 rounded-full transition-all relative z-10",
            isListening && "bg-destructive hover:bg-destructive border-destructive shadow-lg"
          )}
          onClick={onToggle}
          disabled={disabled || isProcessing}
          data-testid="button-voice-toggle"
          aria-label={isListening ? "Stop recording" : "Start recording"}
        >
          {isProcessing ? (
            <Loader2 className="w-6 h-6 animate-spin" />
          ) : isListening ? (
            <MicOff className="w-6 h-6" />
          ) : (
            <Mic className="w-6 h-6" />
          )}
        </Button>
      </div>

      <div className="text-center space-y-1">
        <span className="text-sm text-muted-foreground font-medium" data-testid="text-voice-status">
          {isProcessing ? "Processing..." : isListening ? "Listening..." : "Tap to speak"}
        </span>
        {transcript && isListening && (
          <p className="text-xs text-foreground px-4 py-2 bg-muted rounded-lg max-w-xs">
            {transcript}
          </p>
        )}
      </div>
    </div>
  );
}
