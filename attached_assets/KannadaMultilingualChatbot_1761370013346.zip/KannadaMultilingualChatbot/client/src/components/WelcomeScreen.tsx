import { Mic2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { supportedLanguages } from "@shared/schema";

interface WelcomeScreenProps {
  onLanguageSelect?: (code: string) => void;
}

export function WelcomeScreen({ onLanguageSelect }: WelcomeScreenProps) {
  return (
    <div className="flex flex-col items-center justify-center h-full px-4 py-8" data-testid="welcome-screen">
      <div className="flex flex-col items-center gap-6 max-w-4xl w-full">
        <div className="relative">
          <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center">
            <Mic2 className="w-12 h-12 text-primary" strokeWidth={2} />
          </div>
        </div>

        <div className="text-center space-y-2">
          <h1 className="text-4xl font-semibold text-foreground" data-testid="text-welcome-title">
            Hi! I'm Poly
          </h1>
          <p className="text-lg text-muted-foreground" data-testid="text-welcome-subtitle">
            Speak to me in any language
          </p>
        </div>

        <div className="w-full max-w-3xl mt-8">
          <h2 className="text-sm font-medium text-muted-foreground text-center mb-4">
            I can understand and speak:
          </h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {supportedLanguages.map((language) => (
              <Card
                key={language.code}
                className="p-4 hover-elevate active-elevate-2 cursor-pointer transition-all"
                onClick={() => onLanguageSelect?.(language.code)}
                data-testid={`card-language-${language.code}`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-semibold text-primary">
                      {language.code.toUpperCase()}
                    </span>
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="text-sm font-medium text-foreground truncate">
                      {language.name}
                    </span>
                    <span className="text-xs text-muted-foreground truncate">
                      {language.nativeName}
                    </span>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        <p className="text-sm text-muted-foreground text-center mt-6">
          Start speaking or typing to begin our conversation
        </p>
      </div>
    </div>
  );
}
