import { Message } from "@shared/schema";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { LanguageBadge } from "./LanguageBadge";
import { formatDistanceToNow } from "date-fns";

interface MessageBubbleProps {
  message: Message;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const isUser = message.role === "user";
  const timestamp = formatDistanceToNow(new Date(message.timestamp), { addSuffix: true });

  return (
    <div
      className={`flex gap-4 animate-slide-up ${isUser ? "flex-row-reverse" : "flex-row"}`}
      data-testid={`message-${message.id}`}
    >
      <Avatar className="h-8 w-8 flex-shrink-0" data-testid={`avatar-${message.role}`}>
        <AvatarFallback className={isUser ? "bg-primary text-primary-foreground" : "bg-accent text-accent-foreground"}>
          {isUser ? "U" : "P"}
        </AvatarFallback>
      </Avatar>

      <div className={`flex flex-col gap-2 max-w-md ${isUser ? "items-end" : "items-start"}`}>
        <div
          className={`px-4 py-3 rounded-2xl shadow-sm ${
            isUser
              ? "bg-primary text-primary-foreground rounded-tr-md"
              : "bg-card text-card-foreground border border-card-border rounded-tl-md"
          }`}
          data-testid={`bubble-${message.role}`}
        >
          <p className="text-base leading-relaxed whitespace-pre-wrap break-words">
            {message.content}
          </p>
        </div>

        <div className={`flex items-center gap-2 ${isUser ? "flex-row-reverse" : "flex-row"}`}>
          <LanguageBadge languageCode={message.language} />
          <span className="text-xs text-muted-foreground" data-testid={`timestamp-${message.id}`}>
            {timestamp}
          </span>
        </div>
      </div>
    </div>
  );
}
