import { Badge } from "@/components/ui/badge";
import { supportedLanguages } from "@shared/schema";
import { Globe } from "lucide-react";

interface LanguageBadgeProps {
  languageCode?: string;
}

export function LanguageBadge({ languageCode }: LanguageBadgeProps) {
  if (!languageCode) return null;

  const language = supportedLanguages.find((lang) => lang.code === languageCode);
  if (!language) return null;

  return (
    <Badge 
      variant="secondary" 
      className="px-3 py-1 text-xs font-medium rounded-full animate-fade-in flex items-center gap-1"
      data-testid={`badge-language-${languageCode}`}
    >
      <Globe className="w-3 h-3" />
      {language.code.toUpperCase()}
    </Badge>
  );
}
