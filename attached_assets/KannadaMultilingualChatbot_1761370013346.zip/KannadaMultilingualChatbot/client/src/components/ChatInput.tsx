import { useState, FormEvent } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, Mic } from "lucide-react";

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  onVoiceClick: () => void;
  disabled?: boolean;
  isListening?: boolean;
}

export function ChatInput({ onSendMessage, onVoiceClick, disabled, isListening }: ChatInputProps) {
  const [message, setMessage] = useState("");

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (message.trim() && !disabled) {
      onSendMessage(message.trim());
      setMessage("");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex items-center gap-2 w-full">
      <div className="flex-1 relative">
        <Input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder={isListening ? "Listening..." : "Type your message..."}
          disabled={disabled || isListening}
          className="w-full rounded-full pr-12 h-12 text-base"
          data-testid="input-message"
        />
        <Button
          type="button"
          size="icon"
          variant={isListening ? "default" : "ghost"}
          className={`absolute right-1 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full ${
            isListening ? "bg-destructive hover:bg-destructive" : ""
          }`}
          onClick={onVoiceClick}
          disabled={disabled && !isListening}
          data-testid="button-voice-input"
          aria-label={isListening ? "Stop recording" : "Voice input"}
        >
          <Mic className={`w-5 h-5 ${isListening ? "text-destructive-foreground" : ""}`} />
        </Button>
      </div>

      <Button
        type="submit"
        size="icon"
        disabled={!message.trim() || disabled}
        className="h-12 w-12 rounded-full flex-shrink-0"
        data-testid="button-send"
        aria-label="Send message"
      >
        <Send className="w-5 h-5" />
      </Button>
    </form>
  );
}
