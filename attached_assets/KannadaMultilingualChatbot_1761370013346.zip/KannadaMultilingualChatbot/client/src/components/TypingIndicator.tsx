import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export function TypingIndicator() {
  return (
    <div className="flex gap-4 animate-slide-up" data-testid="typing-indicator">
      <Avatar className="h-8 w-8 flex-shrink-0">
        <AvatarFallback className="bg-accent text-accent-foreground">P</AvatarFallback>
      </Avatar>

      <div className="flex flex-col gap-2">
        <div className="px-4 py-3 rounded-2xl rounded-tl-md bg-card border border-card-border shadow-sm">
          <div className="flex gap-1.5">
            <div 
              className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce-dot"
              style={{ animationDelay: "0ms" }}
            />
            <div 
              className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce-dot"
              style={{ animationDelay: "200ms" }}
            />
            <div 
              className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce-dot"
              style={{ animationDelay: "400ms" }}
            />
          </div>
        </div>
        <span className="text-xs text-muted-foreground ml-1">
          Poly is thinking...
        </span>
      </div>
    </div>
  );
}
