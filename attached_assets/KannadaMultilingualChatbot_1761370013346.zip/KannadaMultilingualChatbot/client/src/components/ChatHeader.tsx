import { Mic2, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { LanguageBadge } from "./LanguageBadge";

interface ChatHeaderProps {
  currentLanguage?: string;
  onNewChat: () => void;
}

export function ChatHeader({ currentLanguage, onNewChat }: ChatHeaderProps) {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 h-16 bg-background border-b border-border">
      <div className="h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <Mic2 className="w-5 h-5 text-primary" strokeWidth={2.5} />
          </div>
          <div className="flex flex-col">
            <h1 className="text-xl font-semibold text-foreground" data-testid="text-app-title">
              Poly
            </h1>
            {currentLanguage && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">Speaking:</span>
                <LanguageBadge languageCode={currentLanguage} />
              </div>
            )}
          </div>
        </div>

        <Button
          variant="outline"
          size="default"
          onClick={onNewChat}
          className="rounded-lg gap-2"
          data-testid="button-new-chat"
        >
          <RotateCcw className="w-4 h-4" />
          <span className="hidden sm:inline">New Chat</span>
        </Button>
      </div>
    </header>
  );
}
