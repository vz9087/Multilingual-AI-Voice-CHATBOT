import type { Express } from "express";
import { createServer, type Server } from "http";
import { chatRequestSchema } from "@shared/schema";
import { detectLanguageAndRespond } from "./openai";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/chat", async (req, res) => {
    try {
      const validatedData = chatRequestSchema.parse(req.body);

      const conversationHistory = (validatedData.conversationHistory || []).map((msg) => ({
        role: msg.role,
        content: msg.content,
      }));

      const result = await detectLanguageAndRespond(
        validatedData.message,
        conversationHistory
      );

      res.json({
        message: result.message,
        detectedLanguage: result.detectedLanguage,
      });
    } catch (error: any) {
      console.error("Chat API error:", error);
      
      if (error.name === "ZodError") {
        res.status(400).json({ 
          error: "Invalid request data",
          details: error.errors 
        });
        return;
      }

      res.status(500).json({ 
        error: error.message || "Failed to process chat message" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
