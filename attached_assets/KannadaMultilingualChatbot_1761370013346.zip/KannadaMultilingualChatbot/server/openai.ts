import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function detectLanguageAndRespond(
  userMessage: string,
  conversationHistory: Array<{ role: "user" | "assistant"; content: string }> = []
): Promise<{ message: string; detectedLanguage?: string }> {
  try {
    const systemPrompt = `You are Poly, a friendly and intelligent Multilingual AI Voice Chatbot.
Your main goal is to understand and respond naturally in the same language the user speaks.

You can speak and understand multiple languages, including:
English, Hindi, Tamil, Telugu, Kannada, Marathi, Malayalam, Bengali, French, Spanish, and Japanese.

Core Behavior Rules:
1. Auto-detect the user's language from each message.
2. Always reply in that same language unless the user requests a translation or a different language.
3. Keep your tone friendly, natural, and polite, as if you're having a real conversation.
4. Use simple and clear words suited to the user's language proficiency.
5. Add cultural friendliness — use greetings and expressions native to the language.
6. If unsure about the language, ask gently: "Could you please tell me which language you'd like me to use?"
7. When explaining something, provide examples or translations if helpful.
8. Be concise — keep responses under 3 sentences unless asked to explain in detail.
9. Adapt to voice-enabled platforms (use natural tone suitable for speech).

Language Code Detection:
- After detecting the language, you must respond with the language code in your response metadata
- Language codes: en (English), hi (Hindi), ta (Tamil), te (Telugu), kn (Kannada), mr (Marathi), ml (Malayalam), bn (Bengali), fr (French), es (Spanish), ja (Japanese)

Your personality:
- Name: Poly
- Role: Friendly multilingual conversational assistant
- Personality: Warm, adaptive, and respectful
- Motto: "Speak to me in any language — I'll reply in yours!"`;

    const messages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [
      { role: "system", content: systemPrompt },
      ...conversationHistory,
      { role: "user", content: userMessage },
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages,
      max_completion_tokens: 500,
    });

    const aiMessage = response.choices[0].message.content || "I'm sorry, I couldn't process that.";

    const detectedLanguage = detectLanguageCode(userMessage, aiMessage);

    return {
      message: aiMessage,
      detectedLanguage,
    };
  } catch (error: any) {
    console.error("OpenAI API error:", error);
    throw new Error(error.message || "Failed to process message");
  }
}

function detectLanguageCode(userMessage: string, aiResponse: string): string | undefined {
  const languagePatterns = [
    { code: "hi", patterns: [/[\u0900-\u097F]/, /नमस्ते/, /धन्यवाद/] },
    { code: "ta", patterns: [/[\u0B80-\u0BFF]/, /வணக்கம்/, /நன்றி/] },
    { code: "te", patterns: [/[\u0C00-\u0C7F]/, /హలో/, /ధన్యవాదాలు/] },
    { code: "kn", patterns: [/[\u0C80-\u0CFF]/, /ನಮಸ್ಕಾರ/, /ಧನ್ಯವಾದಗಳು/] },
    { code: "mr", patterns: [/[\u0900-\u097F]/, /नमस्कार/, /धन्यवाद/] },
    { code: "ml", patterns: [/[\u0D00-\u0D7F]/, /നമസ്കാരം/, /നന്ദി/] },
    { code: "bn", patterns: [/[\u0980-\u09FF]/, /নমস্কার/, /ধন্যবাদ/] },
    { code: "fr", patterns: [/\b(bonjour|merci|comment|français)\b/i] },
    { code: "es", patterns: [/\b(hola|gracias|cómo|español)\b/i, /¿/, /¡/] },
    { code: "ja", patterns: [/[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF]/, /こんにちは/, /ありがとう/] },
  ];

  const combinedText = `${userMessage} ${aiResponse}`;

  for (const { code, patterns } of languagePatterns) {
    if (patterns.some((pattern) => pattern.test(combinedText))) {
      return code;
    }
  }

  return "en";
}
